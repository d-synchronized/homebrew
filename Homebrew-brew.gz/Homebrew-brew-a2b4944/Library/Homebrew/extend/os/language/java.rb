# typed: strict
# frozen_string_literal: true

require "extend/os/mac/language/java" if OS.mac?
