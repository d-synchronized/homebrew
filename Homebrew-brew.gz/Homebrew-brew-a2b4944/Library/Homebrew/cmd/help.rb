# typed: true
# frozen_string_literal: true

require "help"

module Homebrew
  def help
    Help.help
  end
end
