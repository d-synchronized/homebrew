See Homebrew's [releases on GitHub](https://github.com/Homebrew/brew/releases) for the changelog.

Release notes for major and minor releases can also be found in the [Homebrew blog](https://brew.sh/blog/).
